# Fitness App (Спортик)

## Запуск 

**1. Из корня**

```запуск всех сервисов одним таргетом
make up
```

**2. Запуск по отдельности(перейти в 3-х терминалах в соответствующие папки)**

```для ml, backend, frontend
make sportapp-deploy
make env-up (для postgresql в папке backend)
make env-port-forward (в папке backend, чтобы в pgdmin смотреть бд)
```

**3. Порты**

```
backend - 5050
ml - 8000
frontend - 3000
```

**4. Примечание**

```Docker
У меня запускалось всё только при открытом docker desktop.
Все работает в контейнерах, не падая.
```

## Проблема frontend

```
Сайт в браузере открывается, но там просто белое окно, где ничего нельзя делать. Имитируя frontend запросами на backend через postman у меня с ml все работало правильно во всех смыслах.
```




Поднять весь стек (если ещё не запущен): 
docker compose up -d

Перезапустить без пересборки
docker compose restart

Перезапустить один сервис
docker compose restart frontend (или backend, ml, sportapp-postgres)

Пересобрать и поднять один сервис
docker compose up -d --build frontend

Пересобрать всё сразу
docker compose up -d --build

Остановить и убрать контейнеры
docker compose down